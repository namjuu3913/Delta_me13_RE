Experimental cpp lib for py.

Why is this not in the cpplib? --> because it's config. it needs to be at root.